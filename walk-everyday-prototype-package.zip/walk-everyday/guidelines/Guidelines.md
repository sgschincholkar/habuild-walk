# Guidelines

Build a calm wellness-first walking habit app. Use shadcn/ui, Tailwind CSS, mobile-first layouts, Inter typography, rounded cards, warm spacing, and emotionally supportive UX.