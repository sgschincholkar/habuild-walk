# Illustration Guidelines

Use soft flat wellness illustrations with inclusive Indian representation and calm walking poses.