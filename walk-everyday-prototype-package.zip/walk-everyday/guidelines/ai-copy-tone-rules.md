# AI Copy Tone Rules

Tone should be calm, warm, supportive, and non-judgmental. Avoid hustle culture and aggressive motivation.