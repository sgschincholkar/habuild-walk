# Motion Guidelines

Use subtle fade and slide transitions. Standard duration: 200ms ease-out. Avoid bouncy or gamified motion.