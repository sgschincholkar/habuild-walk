# Component Guidelines

Use reusable rounded cards, pill buttons, soft shadows, spacious padding, and fixed bottom navigation.