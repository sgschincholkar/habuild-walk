# Spacing Token System

4px base grid. 20px minimum gutters. 48px touch targets. Large rounded corners and generous spacing.