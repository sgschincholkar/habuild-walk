# Navigation Map

Welcome → Intention → Plan → Home → Walk → Complete → Progress → Settings